package model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class HTTPModels {

    @JsonFormat
    public static final class ReceivedOrderModel {
        @JsonProperty("custId")
        public Integer custId;
        @JsonProperty("restId")
        public final Integer restId;
        @JsonProperty("itemId")
        public final Integer itemId;
        @JsonProperty("qty")
        public final Integer qty;

        @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
        public ReceivedOrderModel(@JsonProperty("custId") Integer custId, @JsonProperty("restId") Integer restId,
                                  @JsonProperty("itemId") Integer itemId, @JsonProperty("qty") Integer qty) {
            this.custId = custId;
            this.restId = restId;
            this.itemId = itemId;
            this.qty = qty;
        }
    }

    @JsonFormat
    public static final class Agent {
        @JsonProperty("agentId")
        public final Integer agentId;

        @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
        public Agent(@JsonProperty("agentId") Integer agentId) {
            this.agentId = agentId;
        }
    }


    @JsonFormat
    public static final class Agent_OUT {
        @JsonProperty("agentId")
        public final Integer agentId;

        @JsonProperty("orderId")
        public final Integer orderId;

        @JsonProperty("status")
        public final String status;

        @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
        public Agent_OUT(@JsonProperty("agentId") Integer agentId, @JsonProperty("orderId") Integer orderId,
                         @JsonProperty("status") String status) {
            this.agentId = agentId;
            this.orderId = orderId;
            this.status = status;
        }

        @Override
        public String toString() {
            return "Agent{" +
                    "agentId=" + agentId +
                    ", orderId=" + orderId +
                    ", status='" + status + '\'' +
                    '}';
        }
    }

    @JsonFormat
    public static final class Order {
        @JsonProperty("agentId")
        public final Integer orderId;

        @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
        public Order(@JsonProperty("orderId") Integer orderId) {
            this.orderId = orderId;
        }
    }
}
