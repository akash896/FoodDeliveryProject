See my email to Arpitha on Sep. 3 2020 about how to run this code and what
output to expect from it.

To work within Eclipse, you may need to right-click on the project and add
the Java Nature. Then, select Build Path -> Configure Build Path
for the project, and add the
"java/" folders in the "Source" tab, so eclipse knows where the sources
are.
