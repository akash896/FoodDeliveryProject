#!/bin/bash
echo"Public10-Project1Phase1.py = "
python3 Public10-Project1Phase1.py

echo"Public1-Project1Phase1.py = "
python3 Public1-Project1Phase1.py

echo"Public2-Project1Phase1.py = "
python3 Public2-Project1Phase1.py

echo"Public3-Project1Phase1.py = "
python3 Public3-Project1Phase1.py

echo"Public4-Project1Phase1.py = "
python3 Public4-Project1Phase1.py

echo"Public5-Project1Phase1.py = "
python3 Public5-Project1Phase1.py

echo"Public6-Project1Phase1.py = "
python3 Public6-Project1Phase1.py

echo"Public7-Project1Phase1.py = "
python3 Public7-Project1Phase1.py

echo"Public8-Project1Phase1.py = "
python3 Public8-Project1Phase1.py

echo"Public9-Project1Phase1.py = "
python3 Public9-Project1Phase1.py
