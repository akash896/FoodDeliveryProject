package db;

public class FindOrder {
    Integer orderId;
    String status;

    public FindOrder(Integer orderId, String status) {
        this.orderId = orderId;
        this.status = status;
    }

    public FindOrder(){}

    @Override
    public String toString() {
        return "FindOrder{" +
                "orderId=" + orderId +
                ", status='" + status + '\'' +
                '}';
    }
}
