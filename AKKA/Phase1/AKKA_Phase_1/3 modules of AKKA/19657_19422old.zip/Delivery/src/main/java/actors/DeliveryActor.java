package actors;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.*;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletionStage;

public class DeliveryActor {

    public static Integer orderNumber = 1000;

    static interface DeliveryCommand {}

    public static class FoundOrder implements DeliveryCommand{
        public final Integer orderId;
        public final String status;

        public FoundOrder(Integer orderId, String status) {
            this.orderId = orderId;
            this.status = status;
        }
    }

    public static class OrderNumber implements DeliveryCommand {
        private Integer orderId;

        public OrderNumber(Integer orderId) {
            this.orderId = orderId;
        }

        public OrderNumber(){}

        public int getOrderId() {
            return orderId;
        }

        public void setOrderId(int orderId) {
            this.orderId = orderId;
        }

        @Override
        public String toString() {
            return "OrderNumber{" +
                    "orderId=" + orderId +
                    '}';
        }

    } // class ends

    public static final class ReInitialize implements DeliveryCommand {
        ActorRef<String> getOrderRef;

        public ReInitialize(ActorRef<String> getOrderRef) {
            this.getOrderRef = getOrderRef;
        }
    }

    public static final class GetOrder implements DeliveryCommand {
        Integer orderId;
        ActorRef<DeliveryActor.FoundOrder> getOrderRef;

        public GetOrder(Integer orderId, ActorRef<FoundOrder> getOrderRef) {
            this.orderId = orderId;
            this.getOrderRef = getOrderRef;
        }
    }

    public static final class RequestOrder implements DeliveryCommand {
        Integer custId;
        Integer itemId;
        Integer restId;
        Integer qty;
        ActorRef<DeliveryActor.OrderNumber> orderNumberActorRef;

        public RequestOrder(Integer custId, Integer itemId, Integer restId, Integer qty, ActorRef<DeliveryActor.OrderNumber> ref) {
            this.custId = custId;
            this.itemId = itemId;
            this.restId = restId;
            this.qty = qty;
            this.orderNumberActorRef = ref;

        }

        @Override
        public String toString() {
            return "RequestOrder{" +
                    "custId=" + custId +
                    ", itemId=" + itemId +
                    ", restId=" + restId +
                    ", qty=" + qty +
                    ", orderNumberActorRef=" + orderNumberActorRef +
                    '}';
        }
    }


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static Behavior<DeliveryCommand> create() { // will return a ChatRoom Actor
        // setup(pointer to a method) takes (pointer to a method which will return an Actor) as argument
        return Behaviors.setup(Delivery::new);
    }

    public static class Delivery extends AbstractBehavior<DeliveryCommand> {
        Map<Integer, ActorRef<FulfillOrder.FulfillOrderCommand>> orderMap = new HashMap<>();


        private Delivery(ActorContext<DeliveryCommand> context) {
            super(context);
        }

        @Override
        public Receive<DeliveryCommand> createReceive() {
            ReceiveBuilder<DeliveryCommand> builder = newReceiveBuilder();

            // saying on receiving ReInitialize message, run this::onReInitialize method
            builder.onMessage(RequestOrder.class, this::onRequestOrder);
            builder.onMessage(GetOrder.class, this::onGetOrder);
            builder.onMessage(ReInitialize.class, this::onReInitialize);
            return builder.build();
        }

        ///////////////////////////////////////////// MESSAGE HANDLERS ///////////////////////////////////////////////////////////////////////////////

        // onGetSession is message handler for getSession message type
        private Behavior<DeliveryCommand> onReInitialize(ReInitialize reInitialize) throws UnsupportedEncodingException {
            // performing reInitialize
            for ( Integer i : orderMap.keySet()) {
                getContext().stop(orderMap.get(i));
            }
            
            orderMap = new HashMap();
            orderNumber = 1000;
            //System.out.println("Reinitialized to " + orderNumber);
            reInitialize.getOrderRef.tell(new String());
            return this;
        }

        private Behavior<DeliveryCommand> onRequestOrder(RequestOrder requestOrder) throws UnsupportedEncodingException {
            ActorRef<FulfillOrder.FulfillOrderCommand> fulfillOrderActor = getContext().
                    spawn(FulfillOrder.FulfillOrderBehaviour.create(orderNumber), "FulfillOrderActor"+orderNumber);
            // calling the fulfill side function
            fulfillOrderActor.tell(new FulfillOrder.FulfillRequestOrder(requestOrder));
            // return to the user
            requestOrder.orderNumberActorRef.tell((new OrderNumber(orderNumber)));
            orderMap.put(orderNumber, fulfillOrderActor);
            orderNumber++;
            return this;
        }

        // getting the Order by using orderId
        private Behavior<DeliveryCommand> onGetOrder(GetOrder getOrder) throws UnsupportedEncodingException {
            if(orderMap.get(getOrder.orderId) == null) {  // order Not present
                getOrder.getOrderRef.tell(new FoundOrder(-99, ""));
            }
            else{
                orderMap.get(getOrder.orderId).tell(new FulfillOrder.RequestedOrderResponse(getOrder.getOrderRef));
                //requestOrder.orderNumberActorRef.tell((new OrderNumber(orderNumber)));
            }
            return this;
        }


    }



}
