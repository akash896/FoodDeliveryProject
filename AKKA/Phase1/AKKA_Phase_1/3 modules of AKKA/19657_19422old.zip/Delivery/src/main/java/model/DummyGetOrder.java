package model;

import java.io.Serializable;

public class DummyGetOrder implements Serializable {

    private int orderId;
    private String status;

    public DummyGetOrder(){}

    public DummyGetOrder(int orderId, String status) {
        this.orderId = orderId;
        this.status = status;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "DummyGetOrder{" +
                "orderId=" + orderId +
                ", status='" + status + '\'' +
                '}';
    }
} // class ends
