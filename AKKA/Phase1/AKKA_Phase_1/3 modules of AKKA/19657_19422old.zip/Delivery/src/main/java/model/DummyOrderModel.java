package model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class DummyOrderModel {

    @JsonFormat
    public static final class ReceivedOrderModel {
        @JsonProperty("custId")
        public Integer custId;
        @JsonProperty("restId")
        public final Integer restId;
        @JsonProperty("itemId")
        public final Integer itemId;
        @JsonProperty("qty")
        public final Integer qty;

        @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
        public ReceivedOrderModel(@JsonProperty("custId") Integer custId, @JsonProperty("restId") Integer restId,
                                  @JsonProperty("itemId") Integer itemId, @JsonProperty("qty") Integer qty) {
            this.custId = custId;
            this.restId = restId;
            this.itemId = itemId;
            this.qty = qty;
        }
    }

//    private int custId;
//    private int restId;
//    private int itemId;
//    private float qty;
//
//    public DummyOrderModel(){}
//
//    public DummyOrderModel(int custId, int restId, int itemId, float qty) {
//        this.custId = custId;
//        this.restId = restId;
//        this.itemId = itemId;
//        this.qty = qty;
//    }


} // class ends



