package actors;

import akka.actor.typed.ActorRef;
import akka.actor.typed.ActorSystem;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.Behaviors;
import akka.http.javadsl.Http;
import akka.http.javadsl.ServerBinding;
import akka.http.javadsl.server.Route;
import java.net.InetSocketAddress;
import java.util.concurrent.CompletionStage;

public class UserGuardian {
    public static String filePath = "/initialData.txt";

    public static void startHttpServer(Route route, ActorSystem<?> system) {
        CompletionStage<ServerBinding> futureBinding =
                Http.get(system).newServerAt("localhost", 8081).bind(route);

        futureBinding.whenComplete((binding, exception) -> {
            if (binding != null) {
                InetSocketAddress address = binding.localAddress();
                system.log().info("Server online at http://{}:{}/",
                        address.getHostString(),
                        address.getPort());
            } else {
                system.log().error("Failed to bind HTTP endpoint, terminating system", exception);
                system.terminate();
            }
        });
    }
    // #start-http-server

    public static Behavior<Void> create() {

        return Behaviors.setup( // context is currently running actor i.e. ChatRoomDemo
                context -> {
                    // context.spawn(DeliveryActor.create(), "DeliveryActor") return an Actor by name DeliveryActor
                    ActorRef<DeliveryActor.DeliveryCommand> deliveryActor = context.spawn(DeliveryActor.create(), "DeliveryActor");

                    DeliveryRoutes userRoutes = new DeliveryRoutes(context.getSystem(), deliveryActor);
                    startHttpServer(DeliveryRoutes.userRoutes(), context.getSystem());

                    // returns an empty actor with no queue
                    return Behaviors.empty(); // don't want to receive any more messages
                });
    }

    public static void main(String[] args) {
        // spawn "user guardian" actor by the name UserGuardian
        filePath = args[0];
        ActorSystem.create(UserGuardian.create(), "UserGuardian");
        }




} // class ends
