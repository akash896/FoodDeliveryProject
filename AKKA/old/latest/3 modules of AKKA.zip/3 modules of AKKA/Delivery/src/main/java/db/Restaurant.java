package db;


import java.io.Serializable;

public class Restaurant implements Serializable {
    private int restId;
    private ItemDB itemDB;

    public Restaurant(){}

    public Restaurant(int restId, ItemDB itemDB){
        this.restId = restId;
        this.itemDB = itemDB;
    }

    public int getRestId() { return restId; }

    public void setRestId(int restId) { this.restId = restId; }

    public ItemDB getItemDB() { return itemDB; }

    public void setItemDB(ItemDB itemDB) { this.itemDB = itemDB; }

}  // class ends
