mvn compile 
mvn exec:java -Dexec.args="/Users/Phoenix/Personal/19657_19422/Delivery/initialData.txt"
# mvn exec:java -Dexec.args=”/Users/Phoenix/IISc/Sem_02/PoDS/Projects/Assignments/Phase_01/Delivery/initialData.txt”
# mvn exec:java -Dexec.args=”/Users/Phoenix/Downloads/initialData.txt”