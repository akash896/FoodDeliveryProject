package actors;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.*;
import db.Agent;
import db.AgentDB;
import db.Restaurant;
import model.HTTPModels;
import utility.DataUtils;

import java.io.*;
import java.util.*;
import java.util.function.Predicate;

public class DeliveryActor {

    public static Integer orderNumber = 1000;

    static interface DeliveryCommand {}

    public static class FoundOrder implements DeliveryCommand{
        public final Integer orderId;
        public final String status;
        public final Integer agentId;

        public FoundOrder(Integer orderId, String status, Integer agentId) {
            this.orderId = orderId;
            this.status = status;
            this.agentId = agentId;
        }
    }

    public static class OrderNumber implements DeliveryCommand {
        private Integer orderId;

        public OrderNumber(Integer orderId) {
            this.orderId = orderId;
        }

        public OrderNumber(){}

        public int getOrderId() {
            return orderId;
        }

        public void setOrderId(int orderId) {
            this.orderId = orderId;
        }

        @Override
        public String toString() {
            return "OrderNumber{" +
                    "orderId=" + orderId +
                    '}';
        }

    } // class ends

    public static final class ReInitialize implements DeliveryCommand {
        ActorRef<String> getOrderRef;

        public ReInitialize(ActorRef<String> getOrderRef) {
            this.getOrderRef = getOrderRef;
        }
    }

    public static final class GetOrder implements DeliveryCommand {
        Integer orderId;
        ActorRef<DeliveryActor.FoundOrder> getOrderRef;

        public GetOrder(Integer orderId, ActorRef<FoundOrder> getOrderRef) {
            this.orderId = orderId;
            this.getOrderRef = getOrderRef;
        }
    }

    public static final class RequestOrder implements DeliveryCommand {
        Integer custId;
        Integer itemId;
        Integer restId;
        Integer qty;
        ActorRef<DeliveryActor.OrderNumber> orderNumberActorRef;

        public RequestOrder(Integer custId, Integer itemId, Integer restId, Integer qty, ActorRef<DeliveryActor.OrderNumber> ref) {
            this.custId = custId;
            this.itemId = itemId;
            this.restId = restId;
            this.qty = qty;
            this.orderNumberActorRef = ref;

        }

        @Override
        public String toString() {
            return "RequestOrder{" +
                    "custId=" + custId +
                    ", itemId=" + itemId +
                    ", restId=" + restId +
                    ", qty=" + qty +
                    ", orderNumberActorRef=" + orderNumberActorRef +
                    '}';
        }
    }

    public static final class AgentAvailable implements DeliveryCommand {}

    public static final class AgentSignIn implements DeliveryCommand {
        private final Integer agentId;
        ActorRef<String> ref;

        public AgentSignIn(ActorRef<String> ref, Integer agentId) {
            this.ref = ref;
            this.agentId = agentId;
        }
    }

    public static final class AgentSignOut implements DeliveryCommand {
        private final Integer agentId;
        ActorRef<String> ref;

        public AgentSignOut(ActorRef<String> ref, Integer agentId) {
            this.ref = ref;
            this.agentId = agentId;
        }
    }

    public static final class OrderDelivered implements DeliveryCommand {
        private final Integer orderId;
        ActorRef<String> ref;

        public OrderDelivered(ActorRef<String> ref, Integer orderId) {
            this.ref = ref;
            this.orderId = orderId;
        }
    }

    public static final class GetAgent implements DeliveryCommand {
        Integer agentId;
        ActorRef<HTTPModels.Agent_OUT> ref;

        public GetAgent(ActorRef<HTTPModels.Agent_OUT> ref, Integer agentId) {
            this.agentId = agentId;
            this.ref = ref;
        }
    }

    public static final class PushToUnAssignedOrders implements DeliveryCommand {
        ActorRef<FulfillOrder.FulfillOrderCommand> ref;
        Integer orderId;

        public PushToUnAssignedOrders(ActorRef<FulfillOrder.FulfillOrderCommand> ref, Integer orderId) {
            this.ref = ref;
            this.orderId = orderId;
        }

    }

    public static final class AgentAssigned implements DeliveryCommand {
        private final Integer orderId;

        public AgentAssigned(Integer orderId) {
            this.orderId = orderId;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof PushToUnAssignedOrders) return (orderId.equals(((PushToUnAssignedOrders) obj).orderId));
            return super.equals(obj);
        }
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static Behavior<DeliveryCommand> create() { // will return a ChatRoom Actor
        // setup(pointer to a method) takes (pointer to a method which will return an Actor) as argument
        return Behaviors.setup(Delivery::new);
    }

    public static class Delivery extends AbstractBehavior<DeliveryCommand> {
        Map<Integer, ActorRef<FulfillOrder.FulfillOrderCommand>> orderMap = new HashMap<>();
        Map<Integer, ActorRef<AgentActor.AgentCommands>> agentRefs = new HashMap<>();
        List<Restaurant> restaurants = new ArrayList<>();
        List<PushToUnAssignedOrders> unAssignedOrders = new ArrayList<>();

        private Delivery(ActorContext<DeliveryCommand> context) {
            super(context);
//          Keeping Restaurant Details in Memonry
            restaurants = List.copyOf(new DataUtils().initializeRestaurant().getAllRestaurants());
//          Creating Agent Actors
            AgentDB agentDB = new DataUtils().initializeAgents();
            for(Agent a: agentDB.getAllAgents()) {
                ActorRef<AgentActor.AgentCommands> agentRef = context.spawn(AgentActor.Agent.create(a), "agent" + a.getAgentId());
                agentRefs.put(a.getAgentId(), agentRef);
            }
        }

        @Override
        public Receive<DeliveryCommand> createReceive() {
            return newReceiveBuilder()

            // saying on receiving ReInitialize message, run this::onReInitialize method
            .onMessage(RequestOrder.class, this::onRequestOrder)
            .onMessage(GetOrder.class, this::onGetOrder)
            .onMessage(ReInitialize.class, this::onReInitialize)
            .onMessage(AgentSignIn.class, this::AgentSignIn)
            .onMessage(AgentSignOut.class, this::AgentSignOut)
            .onMessage(OrderDelivered.class, this::OrderDelivered)
            .onMessage(GetAgent.class, this::GetAgent)
            .onMessage(PushToUnAssignedOrders.class, this::PushToUnAssignedOrders)
            .onMessage(AgentAssigned.class, this::AgentAssigned)
            .onMessage(AgentAvailable.class, this::AgentAvailable)
            .build();
        }

        private Behavior<DeliveryCommand> AgentAvailable(AgentAvailable agentAvailable) {
            System.out.println("AgentAvailable : pending orders : " + unAssignedOrders.size());
            if (unAssignedOrders.size() > 0) {
                unAssignedOrders.get(0).ref.tell(new FulfillOrder.LookForAgent(getContext().getSelf(), agentRefs));
            }
            return this;
        }

        private Behavior<DeliveryCommand> AgentAssigned(AgentAssigned assignedOrder) {
            System.out.println("AgentAssigned before removal: " + unAssignedOrders.size());
            unAssignedOrders.remove(assignedOrder);
            AgentAvailable(new AgentAvailable());
            return this;
        }

        private Behavior<DeliveryCommand> PushToUnAssignedOrders(PushToUnAssignedOrders order) {
            System.out.println("PushToUnAssignedOrders : " + unAssignedOrders.size());
            this.unAssignedOrders.add(order);
            if (unAssignedOrders.size() == 1)
                unAssignedOrders.get(0).ref.tell(new FulfillOrder.LookForAgent(getContext().getSelf(), agentRefs));
            return this;
        }

        private Behavior<DeliveryCommand> GetAgent(GetAgent agent) {
//            for (ActorRef<AgentActor.AgentCommands> a : agentRefs.values())
            if (agentRefs.containsKey(agent.agentId))
                    agentRefs.get(agent.agentId).tell(new AgentActor.GetInfo(agent.ref));
            else
                agent.ref.tell(new HTTPModels.Agent_OUT(-1, -1, "Not Exist"));
            return this;
        }

        private Behavior<DeliveryCommand> OrderDelivered(OrderDelivered order) {
            if (orderMap.containsKey(order.orderId)) {
                orderMap.get(order.orderId).tell(new FulfillOrder.Delivered(getContext().getSelf(), order.orderId));
            }
            order.ref.tell(new String());
            return this;
        }

        private Behavior<DeliveryCommand> AgentSignOut(AgentSignOut agent) {
            if (agentRefs.containsKey(agent.agentId))
            {
                agentRefs.get(agent.agentId).tell(new AgentActor.SignOut());
            }
            agent.ref.tell(new String());
            return this;
        }

        private Behavior<DeliveryCommand> AgentSignIn(AgentSignIn agent) {
            if (agentRefs.containsKey(agent.agentId))
            {
                agentRefs.get(agent.agentId).tell(new AgentActor.SignIn(getContext().getSelf()));
            }
            agent.ref.tell(new String());
            return this;
        }

        ///////////////////////////////////////////// MESSAGE HANDLERS ///////////////////////////////////////////////////////////////////////////////

        // onGetSession is message handler for getSession message type
        private Behavior<DeliveryCommand> onReInitialize(ReInitialize reInitialize) throws UnsupportedEncodingException {
            // performing reInitialize
            for ( ActorRef<FulfillOrder.FulfillOrderCommand> i : orderMap.values())
                getContext().stop(i);

            for (ActorRef<AgentActor.AgentCommands> agent : agentRefs.values())
                agent.tell(new AgentActor.reInitialize());
//            for (ActorRef<AgentActor.AgentCommands> a: agentRefs.values())
//                getContext().stop(a);
//            agentRefs.clear();
//            AgentDB agentDB = new DataUtils().initializeAgents();
//            for(Agent a: agentDB.getAllAgents()) {
//                ActorRef<AgentActor.AgentCommands> agentRef = getContext().spawn(AgentActor.Agent.create(a), "agent" + new Date().getTime()); //+ " ID: " + a.getAgentId()
//                agentRefs.put(a.getAgentId(), agentRef);
//            }


//            restaurants.clear(); // Immutable List so we can' clear it
            orderMap.clear();
            unAssignedOrders.clear();
            orderNumber = 1000;
            //System.out.println("Reinitialized to " + orderNumber);

            restaurants = List.copyOf(new DataUtils().initializeRestaurant().getAllRestaurants());
            reInitialize.getOrderRef.tell(new String());
            return this;
        }

        private Behavior<DeliveryCommand> onRequestOrder(RequestOrder requestOrder) throws UnsupportedEncodingException {
            ActorRef<FulfillOrder.FulfillOrderCommand> fulfillOrderActor = getContext().
                    spawn(FulfillOrder.FulfillOrderBehaviour.create(getContext().getSelf(), orderNumber), "FulfillOrderActor"+orderNumber);
            // calling the fulfill side function
            fulfillOrderActor.tell(new FulfillOrder.FulfillRequestOrder(getContext().getSelf(), requestOrder));
            // return to the user
            requestOrder.orderNumberActorRef.tell((new OrderNumber(orderNumber)));
            orderMap.put(orderNumber, fulfillOrderActor);
            orderNumber++;
            return this;
        }

        // getting the Order by using orderId
        private Behavior<DeliveryCommand> onGetOrder(GetOrder getOrder) throws UnsupportedEncodingException {
            if(orderMap.get(getOrder.orderId) == null) {  // order Not present
                getOrder.getOrderRef.tell(new FoundOrder(-99, "", -1));
            }
            else{
                orderMap.get(getOrder.orderId).tell(new FulfillOrder.RequestedOrderResponse(getOrder.getOrderRef));
                //requestOrder.orderNumberActorRef.tell((new OrderNumber(orderNumber)));
            }
            return this;
        }

    }



}
