package actors;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.*;
import db.*;
import model.DummyOrderModel;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import utility.DataUtils;

import java.io.UnsupportedEncodingException;

public class FulfillOrder {

    public interface FulfillOrderCommand {}

    public static final class FulfillRequestOrder implements FulfillOrderCommand {
        DeliveryActor.RequestOrder deliveryRequestOrder;

        public FulfillRequestOrder(DeliveryActor.RequestOrder deliveryRequestOrder){
            this.deliveryRequestOrder = deliveryRequestOrder;
        }
    }

    public static final class RequestedOrderResponse implements FulfillOrderCommand {
        ActorRef<DeliveryActor.FoundOrder> getOrderRef;
        public RequestedOrderResponse(ActorRef<DeliveryActor.FoundOrder> getOrderRef) {
            this.getOrderRef = getOrderRef;
        }
    }

    public static class FulfillOrderBehaviour extends AbstractBehavior<FulfillOrderCommand> {
        Integer orderid;
        String status;
        public static Behavior<FulfillOrderCommand> create(Integer orderid) {
            return Behaviors.setup(context -> new FulfillOrderBehaviour(context, orderid));
        }

        private FulfillOrderBehaviour(ActorContext<FulfillOrderCommand> context, Integer orderid) {
            super(context);
            this.orderid = orderid;
        }

        @Override
        public Receive<FulfillOrderCommand> createReceive() {
            ReceiveBuilder<FulfillOrderCommand> builder = newReceiveBuilder();

            builder.onMessage(FulfillRequestOrder.class, this::onRequestOrder).build();
            builder.onMessage(RequestedOrderResponse.class, this::onRequestedOrderResponse);
            return builder.build();
        }

        private Behavior<FulfillOrderCommand> onRequestedOrderResponse(RequestedOrderResponse request) {
            request.getOrderRef.tell(new DeliveryActor.FoundOrder(this.orderid, this.status));
            return this;
        }



        private Behavior<FulfillOrderCommand> onRequestOrder(FulfillRequestOrder requestOrder) throws UnsupportedEncodingException {
            // System.out.println("THE REUEST ORDER END POINT WORKING @###################################");

            // System.out.println(requestOrder.deliveryRequestOrder.toString() + "\n");
            // check if customer have enough balance to order that item
            boolean balancePresent = checkBalancePresent(requestOrder.deliveryRequestOrder.custId,
                    requestOrder.deliveryRequestOrder.restId, requestOrder.deliveryRequestOrder.itemId,
                    requestOrder.deliveryRequestOrder.qty);
            // System.out.println("CheckBalance = "+ balancePresent);
            this.status = "unassigned";
            boolean acceptOrder = false;
            RestaurantOperations restaurantOperations = new RestaurantOperations();

            if(balancePresent == true) {
                acceptOrder = restaurantOperations.checkAcceptOrder(requestOrder.deliveryRequestOrder.restId, requestOrder.
                                deliveryRequestOrder.itemId, requestOrder.deliveryRequestOrder.qty);
                if(acceptOrder == false){
                    restaurantOperations.creditBalance(requestOrder.deliveryRequestOrder.custId,
                            requestOrder.deliveryRequestOrder.restId, requestOrder.deliveryRequestOrder.itemId,
                            requestOrder.deliveryRequestOrder.qty);
                }
                if(balancePresent == false || acceptOrder==false){
                    // System.out.println("Final requestOrder check = FALSE");
                }
                else {
                    // System.out.println("Final requestOrder check = TRUE");
                    this.status = "delivered";
                }
            }

            return this;
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public boolean checkBalancePresent(int custId, int restId, int itemId, float quantity) {
            RestaurantDB restaurantDB = new DataUtils().initializeRestaurant();
            float billingPrice = 0;
            if(restaurantDB.getRestaurant(restId) != null) {
                Restaurant restaurant = restaurantDB.getRestaurant(restId);
                Item item = restaurant.getItemDB().getItem(itemId);
                billingPrice = quantity * item.getPrice();
                 // System.out.println("\n Billing Price of order = " + billingPrice);
            }
            else
                return false;
            Customer customer = new Customer(custId, billingPrice);
            Customer customer1 = null;
//        return sendCustomerPostRequest("http://host.docker.internal:8082/deductBalance", customer);
            //sendCustomerPostRequest("http://localhost:8082/reInitialize", customer1);
            return sendCustomerPostRequest("http://localhost:8082/deductBalance", customer);
        }

        private boolean sendCustomerPostRequest(String URI, Customer customer) {
            RestTemplate restTemplate = new RestTemplate();
            HttpEntity<Customer> request = new HttpEntity<>(customer);
            try {
                ResponseEntity<String> response = restTemplate.exchange(URI, HttpMethod.POST, request, String.class);
                if (response.getStatusCode().value() != 201) {
                    return false;
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
            return true;
        }


    }


}
