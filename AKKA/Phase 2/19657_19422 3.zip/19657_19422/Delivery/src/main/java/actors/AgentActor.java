package actors;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;
import model.HTTPModels;

public class AgentActor {

    static interface AgentCommands {}

    public static class SignIn implements AgentCommands{
        ActorRef<DeliveryActor.DeliveryCommand> ref;

        public SignIn(ActorRef<DeliveryActor.DeliveryCommand> ref) {
            this.ref = ref;
        }
    }

    public static class SignOut implements AgentCommands {}

    public static class Delivered implements AgentCommands {
        ActorRef<DeliveryActor.DeliveryCommand> deliveryRef;

        public Delivered(ActorRef<DeliveryActor.DeliveryCommand> deliveryRef) {
            this.deliveryRef = deliveryRef;
        }
    }

    public static class AssignIfAvailable implements AgentCommands {
        ActorRef<FulfillOrder.FulfillOrderCommand> ref;
        ActorRef<DeliveryActor.DeliveryCommand> deliveryRef;
        Integer orderId;

        public AssignIfAvailable(ActorRef<FulfillOrder.FulfillOrderCommand> ref, ActorRef<DeliveryActor.DeliveryCommand> deliveryRef, Integer orderId) {
            this.ref = ref;
            this.orderId = orderId;
            this.deliveryRef = deliveryRef;
        }
    }

    public static class reInitialize implements AgentCommands {}

    public static class GetInfo implements AgentCommands {
        ActorRef<HTTPModels.Agent_OUT> ref;

        public GetInfo(ActorRef<HTTPModels.Agent_OUT> ref) {
            this.ref = ref;
        }
    }

    public static class Agent extends AbstractBehavior<AgentActor.AgentCommands> {

        final Integer agentId;
        int orderId = -1;
//        signed-out, unavailable, available
        String status;

        public static Behavior<AgentActor.AgentCommands> create(db.Agent agent) { // will return a ChatRoom Actor
            // setup(pointer to a method) takes (pointer to a method which will return an Actor) as argument
            return Behaviors.setup(context -> new Agent(context, agent));
        }

        public Agent(ActorContext<AgentCommands> context, db.Agent agent) {
            super(context);
            this.agentId = agent.getAgentId();
            this.orderId = agent.getOrderId();
            this.status = agent.getStatus();
        }

        @Override
        public Receive<AgentCommands> createReceive() {
            return newReceiveBuilder()
                    .onMessage(SignIn.class, this::AgentSignIn)
                    .onMessage(SignOut.class, this::AgentSignOut)
                    .onMessage(Delivered.class, this::OrderDelivered)
                    .onMessage(AssignIfAvailable.class, this::AssignIfAvailable)
                    .onMessage(GetInfo.class, this::GetInfo)
                    .onMessage(reInitialize.class, this::reInitialize)
                    .build();
        }

        private Behavior<AgentCommands> reInitialize(reInitialize initialize) {
            orderId = -1;
            status = "signed-out";
            return this;
        }

        private Behavior<AgentCommands> GetInfo(GetInfo info) {
            info.ref.tell(new HTTPModels.Agent_OUT(this.agentId, this.orderId, this.status));
            return this;
        }

        private Behavior<AgentCommands> AssignIfAvailable(AssignIfAvailable assignIfAvailable) {
            System.out.println("AssignIfAvailable : " + status + " orderId:  " + assignIfAvailable.orderId);
            if (this.status.equals("available"))
            {
                this.status = "unavailable";
                this.orderId = assignIfAvailable.orderId;
                assignIfAvailable.ref.tell(new FulfillOrder.Assigned(getContext().getSelf(), assignIfAvailable.deliveryRef, agentId));
            } else
                assignIfAvailable.ref.tell(new FulfillOrder.LookForNextAgent(assignIfAvailable.deliveryRef));
            return this;
        }

        private Behavior<AgentCommands> OrderDelivered(Delivered delivered) {
            this.status = "available";
            this.orderId = -1;
            delivered.deliveryRef.tell(new DeliveryActor.AgentAvailable());
            return this;
        }

        private Behavior<AgentCommands> AgentSignOut(SignOut signOut) {
            if (status.equals("available"))
                this.status = "signed-out";
            return this;
        }

        private Behavior<AgentCommands> AgentSignIn(SignIn signIn) {
            this.status = "available";
            signIn.ref.tell(new DeliveryActor.AgentAvailable());
//            System.out.println("Agent available " + agentId);
            return this;
        }
    }


    }
