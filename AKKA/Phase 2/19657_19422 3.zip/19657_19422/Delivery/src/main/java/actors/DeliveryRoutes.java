package actors;

import akka.actor.typed.ActorRef;
import akka.actor.typed.ActorSystem;
import akka.actor.typed.Scheduler;
import akka.actor.typed.javadsl.AskPattern;
import akka.http.javadsl.marshallers.jackson.Jackson;
import akka.http.javadsl.model.StatusCodes;
import akka.http.javadsl.server.PathMatchers;
import akka.http.javadsl.server.Route;
import akka.http.javadsl.unmarshalling.Unmarshaller;
import model.DummyOrderModel;
import model.HTTPModels;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.time.Duration;
import java.util.concurrent.CompletionStage;
import static akka.http.javadsl.server.Directives.*;

public class DeliveryRoutes {
    private final static Logger log = LoggerFactory.getLogger(DeliveryRoutes.class);
    private static ActorRef<DeliveryActor.DeliveryCommand> counter = null;
    private static Duration askTimeout = null;
    private static Scheduler scheduler = null;

    public DeliveryRoutes(ActorSystem<?> system, ActorRef<DeliveryActor.DeliveryCommand> counter) {
      this.counter = counter;
      scheduler = system.scheduler();
      askTimeout = system.settings().config().getDuration("my-app.routes.ask-timeout");
    }
  
    private static CompletionStage<DeliveryActor.OrderNumber> requestOrder(Integer custId, Integer itemId, Integer restId, Integer qty) {
      return AskPattern.ask(counter, ref -> 
            new DeliveryActor.RequestOrder(custId, itemId, restId,qty, ref), askTimeout, scheduler
        ); // sending requestOrder request to the DeliveryActor
    }

    private static CompletionStage<DeliveryActor.FoundOrder> getOrder(Integer orderId) {
        return AskPattern.ask(counter, ref ->
                new DeliveryActor.GetOrder(orderId, ref), askTimeout, scheduler
        );
    }

    private static CompletionStage<String> reInitialize() {
        return AskPattern.ask(counter, ref ->
                new DeliveryActor.ReInitialize(ref), askTimeout, scheduler
        ); // calling reInitialize in DeliveryActor
    }

//  Phase 2 Changes
    private static CompletionStage<String> agentSignIn( Integer agentId) {
        return AskPattern.ask(counter, ref ->
                new DeliveryActor.AgentSignIn(ref, agentId), askTimeout, scheduler
        );
    }

    private static CompletionStage<String> agentSignOut( Integer agentId) {
        return AskPattern.ask(counter, ref ->
                new DeliveryActor.AgentSignOut(ref, agentId), askTimeout, scheduler
        );
    }

    private static CompletionStage<String> orderDelivered( Integer orderId) {
        return AskPattern.ask(counter, ref ->
                new DeliveryActor.OrderDelivered(ref, orderId), askTimeout, scheduler
        );
    }

    private static CompletionStage<HTTPModels.Agent_OUT> getAgent( Integer agentId) {
        return AskPattern.ask(counter, ref ->
                new DeliveryActor.GetAgent(ref, agentId), askTimeout, scheduler
        );
    }

    // creating the mapping for the end points required
    public /*static*/ Route userRoutes() {
      return concat( // mapping for requestOrder endPoint
              path("requestOrder", () ->
                    pathEndOrSingleSlash(() -> route(
                            post(() ->
                                            entity(Jackson.unmarshaller(HTTPModels.ReceivedOrderModel.class), receivedOrder ->
                                                    onSuccess(requestOrder(receivedOrder.custId, receivedOrder.itemId,
                                                            receivedOrder.restId, receivedOrder.qty), performed ->
                                                            complete(StatusCodes.CREATED, performed, Jackson.marshaller()))
                                            )
                            ))
                    )

            ), // mapping for getOrder endpoint
              path(PathMatchers.segment("order").slash(PathMatchers.integerSegment()), (Integer orderId) ->
                      get(() ->
                              rejectEmptyResponse(() ->
                                      onSuccess(getOrder(orderId), (performed) -> {
                                          if(performed.orderId == -99)
                                              return complete(StatusCodes.NOT_FOUND, "");
                                          return complete(StatusCodes.OK, performed, Jackson.marshaller());
                                      })
                              )
                      )
                      ),  // mapping for reInitialize
              path("reInitialize", () ->
                      pathEndOrSingleSlash(() -> route(
                              post(() ->
                                      entity(Unmarshaller.entityToString(), var ->
                                              onSuccess(reInitialize(), (performed) ->
                                                      complete(StatusCodes.CREATED, performed))
                                      )
                              ))
                      )
              ),
              path("agentSignIn",
                      () -> pathEndOrSingleSlash(
                      () -> route(
                      post(
                      () -> entity(Jackson.unmarshaller(HTTPModels.Agent.class),
                          agent -> onSuccess(agentSignIn(agent.agentId),
                          performed -> complete(StatusCodes.CREATED, performed))))
              ))),
              path("agentSignOut",
                      () -> pathEndOrSingleSlash(
                      () -> route(
                      post(
                      () -> entity(Jackson.unmarshaller(HTTPModels.Agent.class),
                          agent -> onSuccess(agentSignOut(agent.agentId),
                          performed -> complete(StatusCodes.CREATED, performed))))
              ))),
              path("orderDelivered",
                      () -> pathEndOrSingleSlash(
                      () -> route(
                      post(
                      () -> entity(Jackson.unmarshaller(HTTPModels.Order.class),
                          order -> onSuccess(orderDelivered(order.orderId),
                          performed -> complete(StatusCodes.CREATED, performed))))
              ))),
              path(PathMatchers.segment("agent").slash(PathMatchers.integerSegment()),
                      (Integer agentId) -> get(
                      () -> rejectEmptyResponse(() ->
                                      onSuccess(getAgent(agentId), (performed) -> {
                                          if(performed.agentId == -1)
                                              return complete(StatusCodes.NOT_FOUND, "");
                                          return complete(StatusCodes.OK, performed, Jackson.marshaller());
                                      })
                              )
              ))
        );
    }
}