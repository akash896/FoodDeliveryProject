package actors;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.*;
import db.*;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;
import utility.DataUtils;

import java.io.UnsupportedEncodingException;
import java.util.*;

public class FulfillOrder {

    public interface FulfillOrderCommand {}

    public static final class FulfillRequestOrder implements FulfillOrderCommand {

        private final ActorRef<DeliveryActor.DeliveryCommand> ref;
        DeliveryActor.RequestOrder deliveryRequestOrder;

        public FulfillRequestOrder(ActorRef<DeliveryActor.DeliveryCommand> ref, DeliveryActor.RequestOrder deliveryRequestOrder){
            this.ref = ref;
            this.deliveryRequestOrder = deliveryRequestOrder;
        }
    }

    public static final class RequestedOrderResponse implements FulfillOrderCommand {
        ActorRef<DeliveryActor.FoundOrder> getOrderRef;
        public RequestedOrderResponse(ActorRef<DeliveryActor.FoundOrder> getOrderRef) {
            this.getOrderRef = getOrderRef;
        }
    }

    // Phase-2 Changes
    public static class Assigned implements FulfillOrderCommand {
        private final ActorRef<AgentActor.AgentCommands> ref;
        private final ActorRef<DeliveryActor.DeliveryCommand> deliveryRef;
        private final Integer agentId;

        public Assigned(ActorRef<AgentActor.AgentCommands> ref, ActorRef<DeliveryActor.DeliveryCommand> deliveryRef, int agentId) {
            this.ref = ref;
            this.deliveryRef = deliveryRef;
            this.agentId = agentId;
        }
    }

    public static class LookForNextAgent implements FulfillOrderCommand {

        private final ActorRef<DeliveryActor.DeliveryCommand> deliveryRef;

        public LookForNextAgent(ActorRef<DeliveryActor.DeliveryCommand> deliveryRef) {
            this.deliveryRef = deliveryRef;
        }
    }

    public static class Delivered implements FulfillOrderCommand {
        ActorRef<DeliveryActor.DeliveryCommand> ref;
        Integer orderId;

        public Delivered(ActorRef<DeliveryActor.DeliveryCommand> ref, Integer orderId) {
            this.ref = ref;
            this.orderId = orderId;
        }
    }

    public static class LookForAgent implements FulfillOrderCommand {
        ActorRef<DeliveryActor.DeliveryCommand> ref;
        Map<Integer, ActorRef<AgentActor.AgentCommands>> agentRefs;
        List<Integer> sortedAgents = new ArrayList<>();

        public LookForAgent(ActorRef<DeliveryActor.DeliveryCommand> ref, Map<Integer, ActorRef<AgentActor.AgentCommands>> agentRefs) {
            this.ref = ref;
            this.agentRefs = agentRefs;
            sortedAgents.addAll(agentRefs.keySet());
            Collections.sort(sortedAgents);
        }
    }

    public static class FulfillOrderBehaviour extends AbstractBehavior<FulfillOrderCommand> {
        Integer orderId;
        Integer agentId = -1;
        String status;
        ActorRef<AgentActor.AgentCommands> agentRef;
        Integer searchAgent = -1;
        Map<Integer, ActorRef<AgentActor.AgentCommands>> agentRefs;
        List<Integer> sortedAgents = new ArrayList<>();


        public static Behavior<FulfillOrderCommand> create(ActorRef<DeliveryActor.DeliveryCommand> ref, Integer orderid) {
            return Behaviors.setup(context -> new FulfillOrderBehaviour(context, ref, orderid));
        }

        private FulfillOrderBehaviour(ActorContext<FulfillOrderCommand> context, ActorRef<DeliveryActor.DeliveryCommand> ref, Integer orderId) {
            super(context);
            this.orderId = orderId;
        }

        @Override
        public Receive<FulfillOrderCommand> createReceive() {
            return newReceiveBuilder()
                    .onMessage(FulfillRequestOrder.class, this::onRequestOrder)
                    .onMessage(RequestedOrderResponse.class, this::onRequestedOrderResponse)
                    .onMessage(Delivered.class, this::Delivered)
                    .onMessage(LookForAgent.class, this::LookForAgent)
                    .onMessage(Assigned.class, this::OrderAssigned)
                    .onMessage(LookForNextAgent.class, this::LookForNextAgent)
                    .build();
        }

        private Behavior<FulfillOrderCommand> OrderAssigned(Assigned assigned) {
            this.agentId = assigned.agentId;
            this.status = "assigned";
            assigned.deliveryRef.tell(new DeliveryActor.AgentAssigned(orderId));
            this.agentRef = assigned.ref;
            this.searchAgent = -1;
            return this;
        }

        private Behavior<FulfillOrderCommand> LookForAgent(LookForAgent agents) {
            if (this.status.equals("unassigned"))
            {
                searchAgent = 0;
                this.agentRefs = agents.agentRefs;
                this.sortedAgents = List.copyOf(agents.sortedAgents);
                agentRefs.get(sortedAgents.get(searchAgent)).tell(new AgentActor.AssignIfAvailable(getContext().getSelf(), agents.ref, orderId));
            } else {
                agents.ref.tell(new DeliveryActor.AgentAssigned(orderId));
                System.out.println("LookForAgent : Search Sequence: " + searchAgent);
            }
            return this;
        }

        private Behavior<FulfillOrderCommand> LookForNextAgent(LookForNextAgent agents) {
            System.out.println("LookForNextAgent : Search Sequence: " + searchAgent + " " + sortedAgents.size());
            if (searchAgent < sortedAgents.size()-1 && searchAgent > -1 && status.equals("unassigned"))
                agentRefs.get(sortedAgents.get(++searchAgent)).tell(new AgentActor.AssignIfAvailable(getContext().getSelf(), agents.deliveryRef, orderId));
            else
                searchAgent = -1;

            return this;
        }

        private Behavior<FulfillOrderCommand> Delivered(Delivered delivered) {
            if (this.status.equals("assigned")) {
                this.status = "delivered";

//                Notify the respective Agent Actor to Change Status and notify Delivery actor
                this.agentRef.tell(new AgentActor.Delivered(delivered.ref));
//                this.agentRef = null;
//                this.agentRefs.clear();
//                this.agentRefs = null;
            }
            return this;
        }

        private Behavior<FulfillOrderCommand> onRequestedOrderResponse(RequestedOrderResponse request) {
            request.getOrderRef.tell(new DeliveryActor.FoundOrder(this.orderId, this.status, this.agentId));
            return this;
        }

        private Behavior<FulfillOrderCommand> onRequestOrder(FulfillRequestOrder requestOrder) throws UnsupportedEncodingException {
            // System.out.println("THE REUEST ORDER END POINT WORKING @###################################");

            // System.out.println(requestOrder.deliveryRequestOrder.toString() + "\n");
            // check if customer have enough balance to order that item
            boolean balancePresent = checkBalancePresent(requestOrder.deliveryRequestOrder.custId,
                    requestOrder.deliveryRequestOrder.restId, requestOrder.deliveryRequestOrder.itemId,
                    requestOrder.deliveryRequestOrder.qty);
            // System.out.println("CheckBalance = "+ balancePresent);
            this.status = "unassigned";
            boolean acceptOrder = false;
            RestaurantOperations restaurantOperations = new RestaurantOperations();

            if(balancePresent == true) { // customer have enough balance
                acceptOrder = restaurantOperations.checkAcceptOrder(requestOrder.deliveryRequestOrder.restId, requestOrder.
                                deliveryRequestOrder.itemId, requestOrder.deliveryRequestOrder.qty);
                if(acceptOrder == false){ // restaurant doesnot have enough items
                    restaurantOperations.creditBalance(requestOrder.deliveryRequestOrder.custId,
                            requestOrder.deliveryRequestOrder.restId, requestOrder.deliveryRequestOrder.itemId,
                            requestOrder.deliveryRequestOrder.qty);
                }

                if(balancePresent == false || acceptOrder==false){
                    // System.out.println("Final requestOrder check = FALSE");
                    this.status = "rejected";
                }
                else {
                    // System.out.println("Final requestOrder check = TRUE");
//                    this.status = "delivered"; // marking sttus as delivered in Phase-1
                    requestOrder.ref.tell(new DeliveryActor.PushToUnAssignedOrders(getContext().getSelf(), orderId));
                }
            } else {
                this.status = "rejected";
            }

            return this;
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public boolean checkBalancePresent(int custId, int restId, int itemId, float quantity) {
            RestaurantDB restaurantDB = new DataUtils().initializeRestaurant();
            float billingPrice = 0;
            if(restaurantDB.getRestaurant(restId) != null) {
                Restaurant restaurant = restaurantDB.getRestaurant(restId);
                Item item = restaurant.getItemDB().getItem(itemId);
                billingPrice = quantity * item.getPrice();
                 // System.out.println("\n Billing Price of order = " + billingPrice);
            }
            else
                return false;
            Customer customer = new Customer(custId, billingPrice);
            Customer customer1 = null;
//        return sendCustomerPostRequest("http://host.docker.internal:8082/deductBalance", customer);
            //sendCustomerPostRequest("http://localhost:8082/reInitialize", customer1);
            return sendCustomerPostRequest("http://localhost:8082/deductBalance", customer);
        }

        private boolean sendCustomerPostRequest(String URI, Customer customer) {
            RestTemplate restTemplate = new RestTemplate();
            HttpEntity<Customer> request = new HttpEntity<>(customer);
            try {
                ResponseEntity<String> response = restTemplate.exchange(URI, HttpMethod.POST, request, String.class);
                if (response.getStatusCode().value() != 201) {
                    return false;
                }
            }
            catch (HttpClientErrorException ex) {
                if (ex.getStatusCode().value() == 410) {
                    return false;
                } else 
                ex.printStackTrace();
            }
            catch(Exception e){
                e.printStackTrace();
            }
            return true;
        }


    }

}
